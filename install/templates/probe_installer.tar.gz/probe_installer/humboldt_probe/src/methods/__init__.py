import os
import platform
import subprocess
from .sensors import temperatures, fans, boot_time, uptime, mpv_file_pos_sec, display, easire
from misc import logger, parse_payload, make_response

def call_method(method, *args, **kwargs):
    try:
        result = method(*args, **kwargs)
        response = make_response(
            data=dict(status='complete', result=result)
        )
    except Exception as e:
        response = make_response(
            error=dict(
                message=type(e).__name__,
                errors=e.args
            )
        )
    return response

def shutdown():
    result = os.system('shutdown now')
    if result != 0:
        raise Exception(result)

def reboot():
    result = os.system('reboot now')
    if result != 0:
        raise Exception(result)

def ping():
    return

def is_muted():
    if platform.system() == 'Linux':
        return "MUTED" in subprocess.check_output(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"]).decode()
    else:
        result = subprocess.run(['sc', 'query', 'audiosrv'], capture_output=True, text=True)
        return 'RUNNING' not in result.stdout

def mute():
    if platform.system() == 'Linux':
        subprocess.run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "1"])
    else:
        subprocess.run('net stop audiosrv')

def unmute():
    if platform.system() == 'Linux':
        subprocess.run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "0"])
    else:
        subprocess.run('net start audiosrv')


def unmute():
    if platform.system() == 'Linux':
        from alsaaudio import Mixer
        mixer = Mixer()
        mixer.setmute(False, 0)
    else:
        subprocess.run('net start audiosrv')
