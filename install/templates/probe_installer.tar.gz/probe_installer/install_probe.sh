#!/bin/sh

## needed
sudo apt update
sudo apt -qy install \
python3-click \
python3-paho-mqtt \
python3-setuptools \
python3-psutil \
python3-pip \
python3-alsaaudio

# Remove obsolete wait-for-dhcp-hostname.service
if [ -e /etc/systemd/system/wait-for-dhcp-hostname.service ] ; then
  echo "Found deprecated service wait-for-dhcp-hostname, will delete it..."
  sudo systemctl disable wait-for-dhcp-hostname
  sudo rm -v /usr/bin/wait-for-dhcp-hostname
  sudo rm -v /etc/systemd/system/wait-for-dhcp-hostname.service
fi

## humbold_probe ###############################################################
## Prepare files
[ -e /etc/systemd/system/humboldt-probe.service ] && method="Updating" || method="Installing"
echo "$method and (re)starting /etc/systemd/system/humboldt-probe.service"
cd /home/tu-studio
cd probe_installer/humboldt_probe
sudo mkdir -p /home/tu-studio/humboldt_probe
APP_PY=/home/tu-studio/humboldt_probe/src/app.py
CONFIG_FILE=/home/tu-studio/content/userconfig.txt
MQTT_HOSTNAME=srv-control-avm
CA_CERTIFICATE=/home/tu-studio/humboldt_probe/tls/ca_certificate.pem
CERTFILE=/home/tu-studio/humboldt_probe/tls/client_certificate.pem
KEYFILE=/home/tu-studio/humboldt_probe/tls/client_key.pem
LOGLEVEL=CRITICAL

sudo cp -r ./src /home/tu-studio/humboldt_probe
sudo cp -r ./tls /home/tu-studio/humboldt_probe
sudo chown -R tu-studio:users /home/tu-studio/humboldt_probe
sudo chmod -R 0600 /home/tu-studio/humboldt_probe
sudo chmod 0700 /home/tu-studio/humboldt_probe
sudo chmod 0700 /home/tu-studio/humboldt_probe/tls
sudo chmod 0700 /home/tu-studio/humboldt_probe/src
sudo chmod 0700 /home/tu-studio/humboldt_probe/src/methods
sudo chmod 0700 /home/tu-studio/humboldt_probe/src/misc

## Install service
render_template() {
  eval "echo \"$(cat $1)\""
}

render_template humboldt-probe.service.template | sudo tee /etc/systemd/system/humboldt-probe.service

echo "\nDone!\n"
##################

## Load Dell HW Monitoring kernel module at boot time (late)
if ! [ -e /etc/modprobe.d/dell-smm-hwmon.conf ] ; then
	echo "Forcing dell-smm-hwmon module to be loaded at boot..."
	sudo sh -c 'echo "options dell-smm-hwmon force=1" > /etc/modprobe.d/dell-smm-hwmon.conf'
	sudo sh -c 'echo "dell-smm-hwmon" > /etc/modules-load.d/dell-smm-hwmon.conf'
	sudo modprobe dell-smm-hwmon force=1
fi
##################


## Install python sd-notify
#check if Debian 11 or newer and act accordingly
[ $(lsb_release -sr) = 12 ] && installfix="--break-system-packages "
sudo python3 -m pip install $installfix /home/tu-studio/probe_installer/sd-notify-0.1.0

#Config-file
chmod +x /home/tu-studio/probe_installer/patch_userconfig.py
sudo /home/tu-studio/probe_installer/patch_userconfig.py /home/tu-studio/content/userconfig.txt
sudo chown tu-studio:users /home/tu-studio/content/userconfig.txt

sudo systemctl daemon-reload
sudo systemctl enable humboldt-probe.service
sudo systemctl restart humboldt-probe.service
sudo chmod 665 /home/tu-studio/content/userconfig.txt

echo "Done!"
##################

exit 0
