#!/usr/bin/python3
import sys
import shlex

default_methods = 'ping,temperatures,fans,display,uptime,is_muted'
default_capabilities = 'wake,shutdown,reboot,mute,unmute'

config_file_name = sys.argv[1]

def get_config(config_file):
    config = {}
    try:
        with open(config_file) as f:
            for line in shlex.split(f.read()):
                var, _, value = line.partition('=')
                config[var] = value
    except Exception as e:
        logger.error('Loading config %s', e)
    return config

def add_to_field(config, field_name, value):
    config[field_name] = ','.join(config[field_name].split(',') + [value])
    return config

try:
    config = get_config(config_file_name)

    if 'PROBE_METHODS' in config:
        if not 'is_muted' in config['PROBE_METHODS']:
            config = add_to_field(config, 'PROBE_METHODS', 'is_muted')
    else:
        config['PROBE_METHODS'] = default_methods

    if 'PROBE_CAPABILITIES' in config:
        if not 'mute' in config['PROBE_CAPABILITIES']:
            config = add_to_field(config, 'PROBE_CAPABILITIES', 'mute')
        if not 'unmute' in config['PROBE_CAPABILITIES']:
            config = add_to_field(config, 'PROBE_CAPABILITIES', 'unmute')
    else:
        config['PROBE_CAPABILITIES'] = default_capabilities
except:
    config = {
        'PROBE_METHODS': default_methods,
        'PROBE_CAPABILITIES': default_capabilities
    }

with open(config_file_name, 'w') as f:
    for key, value in config.items():
        f.write(f'{key}="{value}"\n')
